package com.demo.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

public class BankServiceImpl implements BankService {

	@Autowired
	private AccountService accountService;

	@Autowired
	private PlatformTransactionManager transactionManager;

	private TransactionStatus getTransactionStatus() {
		DefaultTransactionDefinition transactionDefinition = new DefaultTransactionDefinition();
		TransactionStatus transactionStatus = transactionManager.getTransaction(transactionDefinition);
		return transactionStatus;
	}

	public Long transfer(Long fromAccountNumber, Long toAccountNumber, int amount) throws SQLException {

		try {
			Long transactionId = accountService.debit(amount, fromAccountNumber);
			accountService.credit(amount, toAccountNumber);
			transactionManager.commit(getTransactionStatus());
			return transactionId;
		} catch (Exception ex) {
			transactionManager.rollback(getTransactionStatus());
		}
		return null;
	}

}
