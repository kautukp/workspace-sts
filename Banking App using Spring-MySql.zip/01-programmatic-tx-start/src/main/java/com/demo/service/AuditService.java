package com.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

public class AuditService {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private PlatformTransactionManager transactionManager;

	public void writeAuditLog(String message) {
		try {
			String query = "insert into auditlogs(logmessage) values(?) ";
			jdbcTemplate.update(query, message);
			transactionManager.commit(getTransactionStatus());
		} catch (Exception ex) {
			transactionManager.rollback(getTransactionStatus());
		}
	}

	private TransactionStatus getTransactionStatus() {
		DefaultTransactionDefinition transactionDefinition = new DefaultTransactionDefinition();
		transactionDefinition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
		TransactionStatus transactionStatus = transactionManager.getTransaction(transactionDefinition);
		return transactionStatus;
	}

}
