/**
 * 
 */
package springdemo.model;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author User
 *
 */
public class Line {

	private Point pointA;
	private Point pointB;

	public Point getPointA() {
		return pointA;
	}

	@Autowired
	public void setPointA(Point pointA) {
		this.pointA = pointA;
	}

	public Point getPointB() {
		return pointB;
	}

	@Autowired
	public void setPointB(Point pointB) {
		this.pointB = pointB;
	}

	public void draw() {
		System.out.println("Point A = " + getPointA().getX() + ", " + getPointA().getY() + ", Point B = "
				+ getPointB().getX() + ", " + getPointB().getY());
	}

}
