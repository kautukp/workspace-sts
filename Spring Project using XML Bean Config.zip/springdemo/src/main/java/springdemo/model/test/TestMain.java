/**
 * 
 */
package springdemo.model.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import springdemo.model.Line;
import springdemo.model.beanconfig.TestJavaConfiguration;

/**
 * @author User
 *
 */
public class TestMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		// Line line = (Line) context.getBean("line");
		// line.draw();

		// Java based annotation
		@SuppressWarnings("resource")
		ApplicationContext ctx = new AnnotationConfigApplicationContext(TestJavaConfiguration.class);
		Line line = ctx.getBean(Line.class);
		line.draw();
	}
}
