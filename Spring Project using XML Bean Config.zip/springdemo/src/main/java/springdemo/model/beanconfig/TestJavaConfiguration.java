/**
 * 
 */
package springdemo.model.beanconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import springdemo.model.Line;
import springdemo.model.Point;

/**
 * @author User
 *
 */
@Configuration
@ComponentScan(basePackages = "springdemo.model.*")
public class TestJavaConfiguration {

	@Bean(name = "pointA")
	public Point pointOneBean() {
		Point point = new Point();
		point.setX(1);
		point.setY(1);
		return point;
	}

	@Bean(name = "pointB")
	public Point pointTwoBean() {
		Point point = new Point();
		point.setX(10);
		point.setY(10);
		return point;
	}

	/*
	@Bean(name = "line")
	public Line lineBean() {
		Line line = new Line();
		line.setPointA(pointOneBean());
		line.setPointB(pointTwoBean());
		return line;
	}
	*/
	
	@Bean(name = "line")
	public Line autowiredLineBean() {
		return new Line();
	}
}
