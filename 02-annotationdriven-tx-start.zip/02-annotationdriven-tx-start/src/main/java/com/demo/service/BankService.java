package com.demo.service;

import java.sql.SQLException;
import java.util.List;

import com.demo.model.Account;


public interface BankService {
	
	public Long transfer(Long fromAccount,Long toAccount,int amount) throws SQLException;
	

}
