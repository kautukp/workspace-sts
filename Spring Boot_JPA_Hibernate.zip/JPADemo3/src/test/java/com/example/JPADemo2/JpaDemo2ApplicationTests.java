package com.example.JPADemo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaDemo2ApplicationTests {

	//@Test
	void contextLoads() {
	}

}
