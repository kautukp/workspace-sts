/**
 * 
 */
/**
 * @author User
 *
 */
package com.jpademo3.entities;